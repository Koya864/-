# カスタマイズガイド

## 主要な変更箇所

### 1. 会社情報変更リスト

#### 会社名「不動産ポータル」の変更箇所
- `index.html` 行19, 43, 402, 425
- `services.html` 行19, 225
- `contact.html` 行19, 304
- `privacy.html` 行19, 147, 169

#### 電話番号「03-1234-5678」の変更箇所
- `index.html` 行313
- `services.html` 行214
- `contact.html` 行72, 261
- `privacy.html` 行149

#### 住所の変更箇所
- `contact.html` 行257-258
- `privacy.html` 行148

#### メールアドレスの変更箇所
- `contact.html` 行93
- `privacy.html` 行150

### 2. 簡単な一括置換方法

テキストエディタ（VS Code、Sublime Text等）の検索・置換機能を使用：

1. **会社名変更**
   ```
   検索: 不動産ポータル
   置換: [新しい会社名]
   ```

2. **電話番号変更**
   ```
   検索: 03-1234-5678
   置換: [新しい電話番号]
   ```

3. **メールアドレス変更**
   ```
   検索: info@fudosan-portal.com
   置換: [新しいメールアドレス]
   ```

### 3. 地域・エリア追加

`index.html` の136-156行目で地域を追加：

```html
<!-- 東海4県に新しい県を追加 -->
<optgroup label="東海4県">
    <option value="aichi">愛知県</option>
    <option value="gifu">岐阜県</option>
    <option value="mie">三重県</option>
    <option value="shizuoka">静岡県</option>
    <!-- 新しい県を追加する場合 -->
    <option value="nagano">長野県</option>
</optgroup>

<!-- 愛知県内市区に新しい市を追加 -->
<optgroup label="愛知県内市区">
    <option value="nagoya">名古屋市</option>
    <!-- 既存の市... -->
    <!-- 新しい市を追加する場合 -->
    <option value="hekinan">碧南市</option>
    <option value="takahama">高浜市</option>
</optgroup>
```

### 4. カラーテーマ変更

`css/style.css` のメインカラー変更箇所：

#### ブルー系グラデーション
```css
/* 現在の設定 */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* 他の色に変更する場合の例 */
/* グリーン系 */
background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);

/* オレンジ系 */
background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
```

### 5. ロゴエリアの変更

会社ロゴ画像を追加する場合：

`index.html` 等の以下の部分を変更：
```html
<!-- 現在（テキストロゴ） -->
<div class="logo">
    <h1><a href="index.html">不動産ポータル</a></h1>
</div>

<!-- 画像ロゴに変更する場合 -->
<div class="logo">
    <a href="index.html">
        <img src="images/logo.png" alt="会社名" height="40">
    </a>
</div>
```

## よくある変更

### サービス内容の変更
`services.html` の67-144行目でサービス内容を変更可能

### お問い合わせフォーム項目の追加
`contact.html` の111-243行目でフォーム項目を追加・削除可能

### フッター情報の変更
各HTMLファイルのフッター部分（`<footer class="footer">`）で変更可能