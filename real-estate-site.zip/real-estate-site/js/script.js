// サンプル物件データ
const properties = [
    {
        id: 1,
        title: "新築高級マンション",
        location: "東京都渋谷区",
        price: "5,800万円",
        type: "apartment",
        area: "tokyo",
        priceRange: "5000-8000",
        rooms: "3LDK",
        area_sqm: "75㎡",
        age: "新築",
        description: "駅徒歩3分の好立地。最新設備完備の高級マンションです。"
    },
    {
        id: 2,
        title: "閑静な住宅街の一戸建て",
        location: "東京都世田谷区",
        price: "7,200万円",
        type: "house",
        area: "tokyo",
        priceRange: "5000-8000",
        rooms: "4LDK",
        area_sqm: "120㎡",
        age: "築5年",
        description: "緑豊かな住宅街にある美しい一戸建て。庭付きで子育てに最適です。"
    },
    {
        id: 3,
        title: "投資用マンション",
        location: "大阪府大阪市",
        price: "2,800万円",
        type: "apartment",
        area: "osaka",
        priceRange: "0-3000",
        rooms: "2LDK",
        area_sqm: "60㎡",
        age: "築10年",
        description: "駅直結の利便性抜群な投資用マンション。安定した収益が期待できます。"
    },
    {
        id: 4,
        title: "モダンデザイン住宅",
        location: "愛知県名古屋市",
        price: "4,500万円",
        type: "house",
        area: "nagoya",
        priceRange: "3000-5000",
        rooms: "3LDK",
        area_sqm: "95㎡",
        age: "築2年",
        description: "建築家設計のモダンデザイン住宅。開放的なリビングが特徴です。"
    },
    {
        id: 5,
        title: "タワーマンション最上階",
        location: "東京都港区",
        price: "1億2,000万円",
        type: "apartment",
        area: "tokyo",
        priceRange: "8000+",
        rooms: "4LDK",
        area_sqm: "150㎡",
        age: "築3年",
        description: "東京湾を一望できるタワーマンション最上階。最高級の住環境です。"
    },
    {
        id: 6,
        title: "リノベーション済みマンション",
        location: "福岡県福岡市",
        price: "2,200万円",
        type: "apartment",
        area: "fukuoka",
        priceRange: "0-3000",
        rooms: "2LDK",
        area_sqm: "55㎡",
        age: "築15年",
        description: "全面リノベーション済み。新築同様の美しさで価格もお手頃です。"
    }
];

// DOM要素
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const propertiesGrid = document.getElementById('properties-grid');

// ハンバーガーメニューの切り替え
hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

// ナビゲーションリンクのクリック時にメニューを閉じる
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
    });
});

// スムーススクロール
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// 物件カードを生成する関数
function createPropertyCard(property) {
    return `
        <div class="property-card" onclick="openPropertyModal(${property.id})">
            <div class="property-image">物件画像 ${property.id}</div>
            <div class="property-content">
                <h3 class="property-title">${property.title}</h3>
                <div class="property-location">📍 ${property.location}</div>
                <div class="property-price">${property.price}</div>
                <div class="property-details">
                    <span class="property-detail">${property.rooms}</span>
                    <span class="property-detail">${property.area_sqm}</span>
                    <span class="property-detail">${property.age}</span>
                </div>
                <p class="property-description">${property.description}</p>
            </div>
        </div>
    `;
}

// 物件を表示する関数
function displayProperties(propertiesToShow = properties) {
    if (propertiesToShow.length === 0) {
        propertiesGrid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1; color: #666; font-size: 18px;">条件に一致する物件が見つかりませんでした。</p>';
        return;
    }
    
    propertiesGrid.innerHTML = propertiesToShow.map(property => createPropertyCard(property)).join('');
}

// 物件検索機能
function searchProperties() {
    const location = document.getElementById('location').value;
    const propertyType = document.getElementById('property-type').value;
    const priceRange = document.getElementById('price-range').value;
    
    let filteredProperties = properties;
    
    // エリアでフィルタ
    if (location) {
        filteredProperties = filteredProperties.filter(property => property.area === location);
    }
    
    // 物件タイプでフィルタ
    if (propertyType) {
        filteredProperties = filteredProperties.filter(property => property.type === propertyType);
    }
    
    // 価格帯でフィルタ
    if (priceRange) {
        filteredProperties = filteredProperties.filter(property => property.priceRange === priceRange);
    }
    
    displayProperties(filteredProperties);
    
    // 結果セクションにスクロール
    document.querySelector('.properties-section').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// 物件詳細モーダルを開く
function openPropertyModal(propertyId) {
    const property = properties.find(p => p.id === propertyId);
    if (!property) return;
    
    // モーダルが存在しない場合は作成
    let modal = document.getElementById('property-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'property-modal';
        modal.className = 'modal';
        document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${property.title}</h2>
                <span class="close" onclick="closePropertyModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="property-image" style="height: 300px; margin-bottom: 30px;">物件画像 ${property.id}</div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                    <div>
                        <h3 style="color: #2c5aa0; margin-bottom: 20px;">物件詳細</h3>
                        <div style="margin-bottom: 15px;"><strong>所在地:</strong> ${property.location}</div>
                        <div style="margin-bottom: 15px;"><strong>価格:</strong> <span style="color: #ff6b6b; font-size: 24px; font-weight: bold;">${property.price}</span></div>
                        <div style="margin-bottom: 15px;"><strong>間取り:</strong> ${property.rooms}</div>
                        <div style="margin-bottom: 15px;"><strong>専有面積:</strong> ${property.area_sqm}</div>
                        <div style="margin-bottom: 15px;"><strong>築年数:</strong> ${property.age}</div>
                        <div style="margin-bottom: 15px;"><strong>物件タイプ:</strong> ${property.type === 'apartment' ? 'マンション' : property.type === 'house' ? '一戸建て' : '土地'}</div>
                    </div>
                    <div>
                        <h3 style="color: #2c5aa0; margin-bottom: 20px;">物件の特徴</h3>
                        <p style="line-height: 1.7; color: #555;">${property.description}</p>
                        <div style="margin-top: 30px;">
                            <button style="background: #2c5aa0; color: white; padding: 15px 30px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; margin-right: 10px; margin-bottom: 10px;" onclick="contactAboutProperty(${property.id})">お問い合わせ</button>
                            <button style="background: #ff6b6b; color: white; padding: 15px 30px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; margin-bottom: 10px;" onclick="scheduleViewing(${property.id})">内見予約</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    modal.style.display = 'block';
    
    // モーダル外クリックで閉じる
    modal.onclick = function(event) {
        if (event.target === modal) {
            closePropertyModal();
        }
    }
}

// 物件詳細モーダルを閉じる
function closePropertyModal() {
    const modal = document.getElementById('property-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// お問い合わせ機能
function contactAboutProperty(propertyId) {
    const property = properties.find(p => p.id === propertyId);
    alert(`「${property.title}」についてのお問い合わせを承りました。\n担当者より24時間以内にご連絡いたします。`);
    closePropertyModal();
    
    // お問い合わせセクションにスクロール
    document.querySelector('#contact').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// 内見予約機能
function scheduleViewing(propertyId) {
    const property = properties.find(p => p.id === propertyId);
    alert(`「${property.title}」の内見予約を承りました。\n担当者より日程調整のご連絡をいたします。`);
    closePropertyModal();
}

// コンタクトフォームの送信処理
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // フォームデータの取得
            const inquiryType = document.getElementById('inquiry-type').value;
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;
            const privacy = document.getElementById('privacy').checked;
            
            // 必須項目のチェック
            if (!inquiryType) {
                alert('お問い合わせ種別を選択してください。');
                return;
            }
            
            if (!name) {
                alert('お名前を入力してください。');
                return;
            }
            
            if (!email) {
                alert('メールアドレスを入力してください。');
                return;
            }
            
            if (!message) {
                alert('詳細・ご要望を入力してください。');
                return;
            }
            
            if (!privacy) {
                alert('プライバシーポリシーに同意してください。');
                return;
            }
            
            // フォーム送信成功
            alert(`お問い合わせありがとうございます。\n\n【お問い合わせ種別】${inquiryType}\n【お名前】${name}\n\n確認次第、担当者よりご連絡いたします。`);
            contactForm.reset();
        });
    }
});

// ページロード時の初期表示
document.addEventListener('DOMContentLoaded', function() {
    displayProperties();
    
    // スクロールアニメーション
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // セクションにアニメーションを適用
    document.querySelectorAll('section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(30px)';
        section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(section);
    });
});

// キーボードショートカット
document.addEventListener('keydown', function(e) {
    // Escキーでモーダルを閉じる
    if (e.key === 'Escape') {
        closePropertyModal();
    }
    
    // Ctrl/Cmd + Kで検索フォームにフォーカス
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('location').focus();
        document.querySelector('#search').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
});

// レスポンシブ対応：ウィンドウサイズ変更時の処理
window.addEventListener('resize', function() {
    // モバイル表示時にナビメニューを閉じる
    if (window.innerWidth > 768) {
        navMenu.classList.remove('active');
    }
});

// 検索フィルターのリセット機能
function resetFilters() {
    document.getElementById('location').value = '';
    document.getElementById('property-type').value = '';
    document.getElementById('price-range').value = '';
    displayProperties();
}

// 検索フィルターにリセットボタンを追加するための関数
document.addEventListener('DOMContentLoaded', function() {
    const searchRow = document.querySelector('.search-row');
    if (searchRow) {
        const resetButton = document.createElement('button');
        resetButton.textContent = 'リセット';
        resetButton.type = 'button';
        resetButton.className = 'search-btn';
        resetButton.style.background = '#6c757d';
        resetButton.onclick = resetFilters;
        resetButton.addEventListener('mouseenter', function() {
            this.style.background = '#5a6268';
        });
        resetButton.addEventListener('mouseleave', function() {
            this.style.background = '#6c757d';
        });
        searchRow.appendChild(resetButton);
    }
});