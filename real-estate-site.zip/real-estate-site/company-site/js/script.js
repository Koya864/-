// ========== DOM要素の取得 ==========
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

// ========== ハンバーガーメニューの制御 ==========
hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

// ナビゲーションリンクをクリックした時にメニューを閉じる
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
    });
});

// ========== スムーススクロール ==========
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ========== お問い合わせフォームの処理 ==========
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // フォームデータの取得
            const formData = new FormData(this);
            const name = formData.get('name');
            const email = formData.get('email');
            const message = formData.get('message');
            
            // 必須項目のチェック
            if (name && email && message) {
                // ★実際の運用時は、ここにフォーム送信処理を追加
                // 例：fetch('/contact', { method: 'POST', body: formData })
                
                alert('お問い合わせありがとうございます。\n確認次第、担当者よりご連絡いたします。');
                contactForm.reset();
            } else {
                alert('必須項目をすべて入力してください。');
            }
        });
    }
});

// ========== スクロール時のアニメーション ==========
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// セクションにアニメーションを適用
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(30px)';
        section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(section);
    });
});

// ========== レスポンシブ対応：ウィンドウサイズ変更時の処理 ==========
window.addEventListener('resize', function() {
    // デスクトップ表示時にナビメニューを閉じる
    if (window.innerWidth > 768) {
        navMenu.classList.remove('active');
    }
});

// ========== ページトップへ戻るボタン（オプション） ==========
// 必要に応じてコメントアウトを外してください
/*
// ページトップボタンの作成
const createScrollTopButton = () => {
    const button = document.createElement('button');
    button.innerHTML = '↑';
    button.className = 'scroll-top-button';
    button.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #3498db;
        color: white;
        border: none;
        font-size: 20px;
        cursor: pointer;
        opacity: 0;
        transition: all 0.3s ease;
        z-index: 1000;
    `;
    
    // ボタンクリック時の処理
    button.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    // スクロール時の表示/非表示制御
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            button.style.opacity = '1';
        } else {
            button.style.opacity = '0';
        }
    });
    
    document.body.appendChild(button);
};

// ページトップボタンの初期化
document.addEventListener('DOMContentLoaded', createScrollTopButton);
*/